#!/usr/bin/env python
import rospy
import numpy as np
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from Lidar_3DOD_2022.msg import object_msg, object_msg_arr
from yolo_v8_msgs.msg import yolo_bbox, yolo_bbox_arr  # Import the new YOLO message types
from sensor_fu.msg import matched_object_msg, matched_object_msg_arr  # Import the new matched object message types

# Camera intrinsics (K) for 640x360 resolution
K = np.array([[260.7129211425781, 0.0, 313.6023254394531],
              [0.0, 260.7129211425781, 174.365234375],
              [0.0, 0.0, 1.0]])

lidar_to_cam = np.array([[0.39050272, 0.92006516, 0.03142808, -0.51655686],
                         [-0.04887838, 0.05481171, -0.99729964, -0.00929451],
                         [-0.91930329, 0.38791207, 0.06637542, 2.99050682],
                         [0, 0, 0, 1]])

def invert_homogeneous_matrix(T):
    # Extract rotation matrix and translation vector
    R = T[0:3, 0:3]
    t = T[0:3, 3]

    # Compute the inverse of the rotation matrix (which is its transpose)
    R_inv = R.T

    # Compute the inverse translation vector
    t_inv = -np.dot(R_inv, t)

    # Construct the inverse homogeneous transformation matrix
    T_inv = np.identity(4)
    T_inv[0:3, 0:3] = R_inv
    T_inv[0:3, 3] = t_inv

    return T_inv

# Compute the inverse of T_lidar_to_cam
cam_to_lidar = invert_homogeneous_matrix(lidar_to_cam)

class ProjectionNode:
    def __init__(self):
        rospy.init_node('projection_node', anonymous=True)
        self.bridge = CvBridge()
        self.lidar_objects = []
        self.yolo_bboxes = []
        self.image = None
        
        self.lidar_sub = rospy.Subscriber('/Lidar_object', object_msg_arr, self.lidar_callback)
        self.image_sub = rospy.Subscriber('/yolov8/img', Image, self.image_callback)
        self.yolo_sub = rospy.Subscriber('/yolov8/bboxes', yolo_bbox_arr, self.yolo_callback)  # Updated subscriber
        self.image_pub = rospy.Publisher('/projected_img', Image, queue_size=10)
        self.matched_obj_pub = rospy.Publisher('/matched_objects', matched_object_msg_arr, queue_size=10)  # Updated publisher

        # Set the rate to 10 Hz
        self.rate = rospy.Rate(10)
        self.last_processed_time = rospy.Time.now()

    def project_to_image_plane(self, point, K, T):
        # Convert point to homogeneous coordinates
        point_h = np.append(point, 1)
        # Transform point from lidar frame to camera frame
        point_cam = np.dot(T, point_h)
        # Project point to image plane
        point_img = np.dot(K, point_cam[:3])
        # Normalize the point
        point_img /= point_img[2]
        return point_img[:2]

    def project_bbox(self, bbox, K, T):
        # Define the 8 corners of the 3D bounding box
        corners = [
            [bbox.xMin, bbox.yMin, bbox.zMin],
            [bbox.xMin, bbox.yMin, bbox.zMax],
            [bbox.xMin, bbox.yMax, bbox.zMin],
            [bbox.xMin, bbox.yMax, bbox.zMax],
            [bbox.xMax, bbox.yMin, bbox.zMin],
            [bbox.xMax, bbox.yMin, bbox.zMax],
            [bbox.xMax, bbox.yMax, bbox.zMin],
            [bbox.xMax, bbox.yMax, bbox.zMax]
        ]
        
        # Project all corners to the image plane
        corners_img = [self.project_to_image_plane(corner, K, T) for corner in corners]
        
        # Ensure the projected points are within image bounds
        for corner in corners_img:
            corner[0] = max(0, min(639, corner[0]))
            corner[1] = max(0, min(359, corner[1]))
        
        # Find the min and max coordinates in the image plane
        x_coords = [corner[0] for corner in corners_img]
        y_coords = [corner[1] for corner in corners_img]
        
        bbox_img = {
            'xMin': min(x_coords),
            'xMax': max(x_coords),
            'yMin': min(y_coords),
            'yMax': max(y_coords)
        }
        
        # Project the center of the bounding box
        center_img = self.project_to_image_plane([bbox.x, bbox.y, bbox.z], K, T)
        center_img[0] = max(0, min(639, center_img[0]))
        center_img[1] = max(0, min(359, center_img[1]))
        
        return bbox_img, center_img

    def lidar_callback(self, msg):
        self.lidar_objects = msg.object_msg_arr
        self.process_and_publish()

    def image_callback(self, msg):
        self.image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        self.process_and_publish()

    def yolo_callback(self, msg):
        self.yolo_bboxes = msg.bboxes
        self.process_and_publish()

    def process_and_publish(self):
        if self.image is not None:
            matched_objects = matched_object_msg_arr()  # Create a new instance of the matched object array message

            # Draw projected 3D bounding boxes on the image if LIDAR objects are available
            if self.lidar_objects:
                for lidar_obj in self.lidar_objects:
                    bbox_img, center_img = self.project_bbox(lidar_obj, K, cam_to_lidar)
                    
                    for yolo_bbox in self.yolo_bboxes:
                        if yolo_bbox.confidence < 0.6:  # Check the confidence level
                            continue
                        
                        iou = self.calculate_iou(bbox_img, yolo_bbox)
                        
                        if iou > 0.005:
                            matched_obj = matched_object_msg()
                            matched_obj.class_name = yolo_bbox.class_name 
                            matched_obj.lidar_x = lidar_obj.x
                            matched_obj.lidar_y = lidar_obj.y
                            matched_obj.lidar_z = lidar_obj.z
                            matched_obj.distance = np.sqrt(lidar_obj.x**2 + lidar_obj.y**2)
                            matched_objects.objects.append(matched_obj)
                            
                            cv2.rectangle(self.image, 
                                          (int(bbox_img['xMin']), int(bbox_img['yMin'])), 
                                          (int(bbox_img['xMax']), int(bbox_img['yMax'])), 
                                          (0, 255, 0), 2)
                            cv2.circle(self.image, (int(center_img[0]), int(center_img[1])), 5, (0, 0, 255), -1)
                            
                            cv2.rectangle(self.image, 
                                          (int(yolo_bbox.xMin), int(yolo_bbox.yMin)), 
                                          (int(yolo_bbox.xMax), int(yolo_bbox.yMax)), 
                                          (255, 0, 0), 2)

            # Convert the image back to ROS Image message and publish
            img_msg = self.bridge.cv2_to_imgmsg(self.image, "bgr8")
            self.image_pub.publish(img_msg)

            # Publish matched objects
            self.matched_obj_pub.publish(matched_objects)  # Publish the matched object array

            # Update the last processed time
            self.last_processed_time = rospy.Time.now()

    def calculate_iou(self, bbox1, bbox2):
        # Calculate intersection
        xA = max(bbox1['xMin'], bbox2.xMin)
        yA = max(bbox1['yMin'], bbox2.yMin)
        xB = min(bbox1['xMax'], bbox2.xMax)
        yB = min(bbox1['yMax'], bbox2.yMax)
        
        interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)
        
        # Calculate union
        boxAArea = (bbox1['xMax'] - bbox1['xMin'] + 1) * (bbox1['yMax'] - bbox1['yMin'] + 1)
        boxBArea = (bbox2.xMax - bbox2.xMin + 1) * (bbox2.yMax - bbox2.yMin + 1)
        
        iou = interArea / float(boxAArea + boxBArea - interArea)
        
        return iou

def main():
    node = ProjectionNode()
    rospy.spin()

if __name__ == '__main__':
    main()

