#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Point 
from sensor_fu.msg import matched_object_msg_arr, matched_object_msg 
from std_msgs.msg import Float32
import math
import utm

class LidarToUTMConverter:
    def __init__(self):
        self.translation_vector = [0.20, 0.13, -0.12]
        self.yaw_angle = 0.0
        self.robot_utm_position = [0.0, 0.0, 0.0]
        self.ref_lat = 37.0  # 기준점의 위도 하이테크 정문??
        self.ref_lon = 127.0  # 기준점의 경도

        rospy.Subscriber('/matched_objects', matched_object_msg_arr, self.lidar_callback)
        rospy.Subscriber('/yaw_angle', Float32, self.yaw_callback)
        rospy.Subscriber('/utm_coordinates', Point, self.utm_callback)
        self.pub = rospy.Publisher('/utm_objects', matched_object_msg_arr, queue_size=10)

    def yaw_callback(self, msg):
        self.yaw_angle = msg.data

    def utm_callback(self, msg):
        self.robot_utm_position = [msg.x, msg.y, msg.z]

    def lidar_callback(self, msg):
        utm_objects = matched_object_msg_arr()
        utm_object_list = []
        for obj in msg.objects:
            x_lidar, y_lidar, z_lidar = obj.lidar_x, obj.lidar_y, obj.lidar_z
            x_lidar += self.translation_vector[0]
            y_lidar += self.translation_vector[1]
            z_lidar += self.translation_vector[2]

            x_enu, y_enu, z_enu = self.lidar_to_enu_3d(x_lidar, y_lidar, z_lidar, self.yaw_angle)

            utm_x, utm_y, utm_z, utm_zone_num, utm_zone_letter = self.enu_to_utm(self.ref_lat, self.ref_lon, x_enu, y_enu, z_enu)

         
            obj_utm_x = self.robot_utm_position[0] + utm_x
            obj_utm_y = self.robot_utm_position[1] + utm_y
            obj_utm_z = self.robot_utm_position[2] + utm_z

            utm_obj = matched_object_msg(
                class_name=obj.class_name,
                lidar_x=obj_utm_x,
                lidar_y=obj_utm_y,
                lidar_z=obj_utm_z,
                distance=obj.distance
            )
            utm_object_list.append(utm_obj)
        
        utm_object_list.sort(key=lambda obj: obj.distance)
        utm_objects.objects = utm_object_list
        
        self.pub.publish(utm_objects)

    def lidar_to_enu_3d(self, x_l, y_l, z_l, yaw):
        cos_theta = math.cos(yaw)
        sin_theta = math.sin(yaw)
        x_enu = cos_theta * x_l - sin_theta * y_l
        y_enu = sin_theta * x_l + cos_theta * y_l
        z_enu = z_l
        return x_enu, y_enu, z_enu

    def enu_to_utm(self, ref_lat, ref_lon, x_enu, y_enu, z_enu):
        ref_utm_x, ref_utm_y, ref_utm_zone_num, ref_utm_zone_letter = utm.from_latlon(ref_lat, ref_lon)
        utm_x = ref_utm_x + x_enu
        utm_y = ref_utm_y + y_enu
        utm_z = z_enu
        return utm_x, utm_y, utm_z, ref_utm_zone_num, ref_utm_zone_letter

if __name__ == '__main__':
    rospy.init_node('lidar_to_utm_converter')
    converter = LidarToUTMConverter()
    rospy.spin()

